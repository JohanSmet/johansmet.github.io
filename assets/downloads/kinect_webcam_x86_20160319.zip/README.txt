Kinect Webcam - A DirectShow filter for Kinect
==============================================

Makes your kinect available as a webcam to application that support
DirectShow. Works with Kinect for Windows v2 and the original kinect.

Installation
------------
Run kw_config.exe with administrator privileges and click the "Register Filter" button on the "Advanced" tab. Alternatively you can run "regsrv32 kinect_webcam.ax" from an elevated command prompt in the installation folder of this application.

Contact
-------
Please visit the project website http://www.justcode.be/projects/kinectwebcam for more information.
The author can be reached via e-mail at johan.smet@justcode.be.

Release history
---------------
2015/01/04 - Initial (binary) public release
2015/01/11 - This release should work better with Skype for Desktop
2016/03/19 - Try to load available Kinect SDK's at runtime. Filter won't fail
             anymore when a Kinect v1 or v2 runtime isn't installed.

Disclaimer of Warranty
----------------------
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
